docker compose down

echo ''
echo 'The OpenRMF Stack has been shut down.'
echo ''